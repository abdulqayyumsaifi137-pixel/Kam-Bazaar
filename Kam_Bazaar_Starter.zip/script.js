function showMessage() {
    alert("Hello! Welcome to Kam Bazaar!");
}